﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Button.Controllers
{
    [Area("Button")]
    public class ButtonClickController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Button/ButtonClick
        public IActionResult Index()
        {
            ViewBag.btnClientClick2Script = Alert.GetShowInTopReference("通过ViewBag传递的客户端事件");

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult btnServerClick_Click()
        {
            ShowNotify("这是服务器端事件");
            return UIHelper.Result();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult btnChangeClientClick2_Click()
        {
            UIHelper.Button("btnClientClick2").ClientClick(Alert.GetShowInTopReference("客户端事件已改变！"));

            return UIHelper.Result();
        }


    }
}