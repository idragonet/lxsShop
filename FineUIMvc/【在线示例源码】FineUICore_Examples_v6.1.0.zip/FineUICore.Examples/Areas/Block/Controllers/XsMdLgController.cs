﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Block.Controllers
{
	[Area("Block")]
    public class XsMdLgController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Block/XsMdLg
        public IActionResult Index()
        {
            return View();
        }

        
    }
}