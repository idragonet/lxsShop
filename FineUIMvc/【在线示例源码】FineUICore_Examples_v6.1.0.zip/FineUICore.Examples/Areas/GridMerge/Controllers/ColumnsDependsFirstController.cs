﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.GridMerge.Controllers
{
    [Area("GridMerge")]
    public class ColumnsDependsFirstController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: GridMerge/ColumnsDependsFirst
        public IActionResult Index()
        {
            return View();
        }


    }
}