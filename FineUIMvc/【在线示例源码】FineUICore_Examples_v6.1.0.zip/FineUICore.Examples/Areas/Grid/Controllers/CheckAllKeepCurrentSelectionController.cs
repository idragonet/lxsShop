﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Grid.Controllers
{
    [Area("Grid")]
    public class CheckAllKeepCurrentSelectionController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Grid/CheckAllKeepCurrentSelection
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult btnSubmit_Click()
        {
			

            return UIHelper.Result();
        }

    }
}