﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Button.Controllers
{
    [Area("Button")]
    public class ButtonGroupController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Button/ButtonGroup
        public IActionResult Index()
        {
            return View();
        }


       

    }
}