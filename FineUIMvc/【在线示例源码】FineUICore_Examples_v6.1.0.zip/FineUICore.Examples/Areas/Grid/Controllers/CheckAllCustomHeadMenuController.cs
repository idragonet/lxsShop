﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Grid.Controllers
{
	[Area("Grid")]
    public class CheckAllCustomHeadMenuController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Grid/CheckAllCustomHeadMenu
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Button2_Click()
        {
            UIHelper.Grid("Grid1").SelectedRowIndexArray(1, 5, 7);

            return UIHelper.Result();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Button1_Click(JArray selected)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<table class=\"result\"><tr><th>ID</th><th>Text</th><th>性别</th><th>专业</th></tr>");

            foreach (JArray item in selected)
            {
                sb.AppendFormat("<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td></tr>",
                    item[0], item[1], 
                    Convert.ToInt32(item[2].ToString()) == 1 ? "男" : "女",
                    item[3]);
            }

            sb.Append("</table>");

            ShowNotify(sb.ToString(), MessageBoxIcon.None);

            return UIHelper.Result();
        }


    }
}