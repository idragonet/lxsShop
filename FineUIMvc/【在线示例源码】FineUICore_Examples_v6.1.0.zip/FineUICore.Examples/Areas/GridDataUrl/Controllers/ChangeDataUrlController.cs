﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using Newtonsoft.Json.Linq;


namespace FineUICore.Examples.Areas.GridDataUrl.Controllers
{
    [Area("GridDataUrl")]
    public class ChangeDataUrlController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: GridDataUrl/ChangeDataUrl
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Button2_Click(string gridSourceKey)
        {
            var grid1 = UIHelper.Grid("Grid1");

            if (gridSourceKey == "source1") {
                grid1.Attribute("data-source-key", "source2");
                grid1.DataUrl(Url.Content("~/GridDataUrl/GridDataUrlData?data2=true"));
            } else {
                grid1.Attribute("data-source-key", "source1");
                grid1.DataUrl(Url.Content("~/GridDataUrl/GridDataUrlData"));
            }

            return UIHelper.Result();
        }

    }
}