﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using Newtonsoft.Json.Linq;


namespace FineUICore.Examples.Areas.Grid.Controllers
{
    [Area("Grid")]
    public class FormController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Grid/Form
        public IActionResult Index()
        {
            return View();
        }


    }
}