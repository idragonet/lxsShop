﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.GridLockColumn.Controllers
{
    [Area("GridLockColumn")]
    public class GroupFieldController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: GridLockColumn/GroupField
        public IActionResult Index()
        {
            return View();
        }

        

    }
}