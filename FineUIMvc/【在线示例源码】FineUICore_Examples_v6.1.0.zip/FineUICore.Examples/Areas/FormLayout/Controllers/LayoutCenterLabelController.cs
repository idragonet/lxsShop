﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace FineUICore.Examples.Areas.FormLayout.Controllers
{
    [Area("FormLayout")]
    public class LayoutCenterLabelController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: FormLayout/LayoutCenterLabel
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult btnSubmit_Click(IFormCollection values)
        {
            ShowNotify(values);

            return UIHelper.Result();
        }

    }
}