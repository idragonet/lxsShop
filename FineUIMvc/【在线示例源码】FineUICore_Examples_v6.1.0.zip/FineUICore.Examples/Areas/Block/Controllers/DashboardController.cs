﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Block.Controllers
{
	[Area("Block")]
    public class DashboardController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Block/Dashboard
        public IActionResult Index()
        {
            return View();
        }

        
    }
}