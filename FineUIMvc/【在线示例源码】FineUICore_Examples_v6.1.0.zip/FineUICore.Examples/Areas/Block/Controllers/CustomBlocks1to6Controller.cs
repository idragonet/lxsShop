﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Block.Controllers
{
    [Area("Block")]
    public class CustomBlocks1to6Controller : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Block/CustomBlocks1to6
        public IActionResult Index()
        {
            return View();
        }

        
    }
}