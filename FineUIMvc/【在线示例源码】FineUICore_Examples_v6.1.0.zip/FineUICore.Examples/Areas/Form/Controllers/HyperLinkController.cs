﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Form.Controllers
{
    [Area("Form")]
    public class HyperLinkController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Form/HyperLink
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult btnChangeEnable_Click(bool enabled)
        {
            var HyperLink2 = UIHelper.HyperLink("HyperLink2");

            if (!enabled)
            {
                HyperLink2.Enabled(true);
                HyperLink2.OnClientClick(Alert.GetShowInParentReference("这是链接的客户端提示"));
            }
            else
            {
                HyperLink2.Enabled(false);
                HyperLink2.OnClientClick("");
            }

            return UIHelper.Result();
        }

    }
}