﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using Newtonsoft.Json.Linq;


namespace FineUICore.Examples.Areas.GridTree.Controllers
{
    [Area("GridTree")]
    public class NoIconsController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: GridTree/NoIcons
        public IActionResult Index()
        {
            return View();
        }


    }
}