﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.FormLayout.Controllers
{
    [Area("FormLayout")]
    public class LayoutContactUsController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: FormLayout/LayoutContactUs
        public IActionResult Index()
        {
            return View();
        }

    }
}