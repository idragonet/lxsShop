﻿using FineUICore.Examples.Areas.DataModel.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.DataModel.Controllers
{
    [Area("DataModel")]
    public class UICompareController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: DataModel/UICompare
        public IActionResult Index()
        {
            var model = new UICompareModel();
            model.StartDate = DateTime.Now;
            model.Number1 = 30;

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult btnSubmit_Click([Bind("StartDate", "EndDate", "Password", "ConfirmPassword", "Number1", "Number2")]UICompareModel compareModel)
        {
            if (ModelState.IsValid)
            {
                ShowNotify(String.Format("用户提交的数据：<br/><pre>{0}</pre>", JsonConvert.SerializeObject(compareModel, Formatting.Indented)));
            }

            return UIHelper.Result();
        }

    }
}