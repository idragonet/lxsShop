﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Editor.Controllers
{
    [Area("Editor")]
    public class UEditorTabStripController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Editor/UEditorTabStrip
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Button1_Click(string text1, string text2)
        {
            ShowNotify(String.Format("编辑器一：{0}<br/>编辑器二：{1}", text1, text2));

            return UIHelper.Result();
        }

    }
}