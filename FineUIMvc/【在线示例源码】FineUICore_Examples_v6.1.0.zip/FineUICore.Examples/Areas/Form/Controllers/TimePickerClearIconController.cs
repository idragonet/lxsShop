﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace FineUICore.Examples.Areas.Form.Controllers
{
    [Area("Form")]
    public class TimePickerClearIconController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Form/TimePickerClearIcon
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult btnSubmit_Click(IFormCollection values)
        {
            var result = String.Format("日期：{0}  时间：{1}",
                values["DatePicker1"],
                values["TimePicker1"]);

            UIHelper.Label("labResult").Text(result);

            return UIHelper.Result();
        }

    }
}