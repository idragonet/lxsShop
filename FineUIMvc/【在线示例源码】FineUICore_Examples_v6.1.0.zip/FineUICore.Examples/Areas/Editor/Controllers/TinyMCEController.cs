﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Editor.Controllers
{
    [Area("Editor")]
    public class TinyMCEController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Editor/TinyMCE
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Button1_Click(string text)
        {
            if (String.IsNullOrEmpty(text))
            {
                ShowNotify("编辑器内容为空！");
            }
            else
            {
                ShowNotify(text);
            }

            return UIHelper.Result();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Button2_Click()
        {
            UIHelper.HtmlEditor("HtmlEditor1").Text("<p><strong>FineUICore</strong> - 基于 jQuery 的专业 ASP.NET Core 控件库。</p>");

            return UIHelper.Result();
        }


    }
}