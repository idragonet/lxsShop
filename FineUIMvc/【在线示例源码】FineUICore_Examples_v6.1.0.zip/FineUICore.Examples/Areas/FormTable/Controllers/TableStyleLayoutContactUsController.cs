﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace FineUICore.Examples.Areas.FormTable.Controllers
{
    [Area("FormTable")]
    public class TableStyleLayoutContactUsController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: FormTable/TableStyleLayoutContactUs
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult btnSubmit_Click(IFormCollection values)
        {
            
            ShowNotify(values);

            return UIHelper.Result();
        }

    }
}