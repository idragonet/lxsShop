﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.IO;

namespace FineUICore.Examples.Areas.Form.Controllers
{
    [Area("Form")]
    public class FileUploadController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Form/FileUpload
        public IActionResult Index()
        {
            return View();
        }

        // https://stackoverflow.com/questions/29836342/mvc-6-httppostedfilebase
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult btnSubmit_Click(IFormFile filePhoto, IFormCollection values)
        {
            if (filePhoto != null)
            {
                string fileName = filePhoto.FileName;

                if (!ValidateFileType(fileName))
                {
                    // 清空文件上传组件
                    UIHelper.FileUpload("filePhoto").Reset();

                    ShowNotify("无效的文件类型！");
                }
                else
                {
                    fileName = fileName.Replace(":", "_").Replace(" ", "_").Replace("\\", "_").Replace("/", "_");
                    fileName = DateTime.Now.Ticks.ToString() + "_" + fileName;
                    
                    using (var stream = new FileStream(PageContext.MapWebPath("~/upload/" + fileName), FileMode.Create))
                    {
                        filePhoto.CopyTo(stream);
                    }
                    
                    UIHelper.Label("labResult").Text("<p>文件路径：" + filePhoto.FileName + "</p>" +
                        "<p>用户名：" + values["tbxUserName"] + "</p>" +
                        "<p>头像：<br /><img src=\"" + Url.Content("~/upload/" + fileName) + "\" /></p>",
                        encodeText: false);

                    // 清空表单字段
                    UIHelper.SimpleForm("SimpleForm1").Reset();
                }
            }

            return UIHelper.Result();
        }

    }
}