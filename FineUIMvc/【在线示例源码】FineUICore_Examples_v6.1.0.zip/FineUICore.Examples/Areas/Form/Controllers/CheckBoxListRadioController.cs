﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Form.Controllers
{
    [Area("Form")]
    public class CheckBoxListRadioController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Form/CheckBoxListRadio
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult CheckBoxList1_Change(string selected)
        {
            ShowNotify(String.Format("列表一选中项的值：{0}", selected));

            return UIHelper.Result();
        }

    }
}