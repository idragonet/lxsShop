﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using Newtonsoft.Json.Linq;


namespace FineUICore.Examples.Areas.GridDataUrl.Controllers
{
    [Area("GridDataUrl")]
    public class LargeData1000Controller : FineUICore.Examples.Controllers.BaseController
    {
        // GET: GridDataUrl/LargeData1000
        public IActionResult Index()
        {
            return View();
        }


    }
}