﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using Newtonsoft.Json.Linq;


namespace FineUICore.Examples.Areas.GridDataUrl.Controllers
{
    [Area("GridDataUrl")]
    public class TreeGridController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: GridDataUrl/TreeGrid
        public IActionResult Index()
        {
            return View();
        }


    }
}