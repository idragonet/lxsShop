﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Block.Controllers
{
	[Area("Block")]
    public class SameWidthController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Block/SameWidth
        public IActionResult Index()
        {
            return View();
        }

        
    }
}