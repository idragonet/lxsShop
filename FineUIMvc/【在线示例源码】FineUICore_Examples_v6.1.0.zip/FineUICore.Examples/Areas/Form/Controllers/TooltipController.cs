﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Form.Controllers
{
    [Area("Form")]
    public class TooltipController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Form/Tooltip
        public IActionResult Index()
        {
            return View();
        }

    }
}