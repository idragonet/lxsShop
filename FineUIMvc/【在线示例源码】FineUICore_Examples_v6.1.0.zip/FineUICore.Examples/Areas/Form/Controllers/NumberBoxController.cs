﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace FineUICore.Examples.Areas.Form.Controllers
{
    [Area("Form")]
    public class NumberBoxController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Form/NumberBox
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult btnSubmit_Click(IFormCollection values)
        {
            ShowNotify(values);
            
            return UIHelper.Result();
        }

    }
}