﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Basic.Controllers
{
    [Area("Basic")]
    public class MainBootstrapPureController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Basic/MainBootstrapPure
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult btnCustomIcon_Click(string iconFont)
        {
            var btnCustomIconFont = UIHelper.Button("btnCustomIcon");

            if (iconFont == "volume-up")
            {
                btnCustomIconFont.IconFont(IconFont._VolumeDown);
            }
            else if (iconFont == "volume-down")
            {
                btnCustomIconFont.IconFont(IconFont._VolumeOff);
            }
            else
            {
                btnCustomIconFont.IconFont(IconFont._VolumeUp);
            }

            return UIHelper.Result();
        }

    }
}