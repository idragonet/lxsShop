﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.GridMerge.Controllers
{
    [Area("GridMerge")]
    public class CellsController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: GridMerge/Cells
        public IActionResult Index()
        {
            return View();
        }


    }
}