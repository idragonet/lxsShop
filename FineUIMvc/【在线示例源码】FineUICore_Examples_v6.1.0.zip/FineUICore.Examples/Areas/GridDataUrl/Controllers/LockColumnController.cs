﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using Newtonsoft.Json.Linq;


namespace FineUICore.Examples.Areas.GridDataUrl.Controllers
{
    [Area("GridDataUrl")]
    public class LockColumnController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: GridDataUrl/LockColumn
        public IActionResult Index()
        {
            return View();
        }


    }
}