﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.GridLockColumn.Controllers
{
    [Area("GridLockColumn")]
    public class GroupFieldRowExpanderController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: GridLockColumn/GroupFieldRowExpander
        public IActionResult Index()
        {
            return View();
        }


    }
}