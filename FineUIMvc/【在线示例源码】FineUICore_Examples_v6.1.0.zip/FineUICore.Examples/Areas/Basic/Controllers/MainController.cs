﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Basic.Controllers
{
    [Area("Basic")]
    public class MainController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Basic/Main
        public IActionResult Index()
        {
            return View();
        }

    }
}