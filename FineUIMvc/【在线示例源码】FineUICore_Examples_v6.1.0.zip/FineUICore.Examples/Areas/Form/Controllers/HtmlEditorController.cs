﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Form.Controllers
{
    [Area("Form")]
    public class HtmlEditorController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Form/HtmlEditor
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Button1_Click(string content)
        {
            // 为了防止出现错误：从客户端中检测到有潜在危险的 Request.Form 值
            // 在客户端对 HtmlEditor1 的内容进行了编码，所以这样需要先解码
            UIHelper.TextArea("TextArea1").Text(HttpUtility.HtmlDecode(content));

            return UIHelper.Result();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Button2_Click(string content)
        {
            UIHelper.HtmlEditor("HtmlEditor1").Text(content);

            return UIHelper.Result();
        }

    }
}