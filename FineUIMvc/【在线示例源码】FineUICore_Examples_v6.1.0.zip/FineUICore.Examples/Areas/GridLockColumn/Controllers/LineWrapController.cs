﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.GridLockColumn.Controllers
{
    [Area("GridLockColumn")]
    public class LineWrapController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: GridLockColumn/LineWrap
        public IActionResult Index()
        {
            return View();
        }


    }
}