﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.GridMerge.Controllers
{
    [Area("GridMerge")]
    public class ColumnsGroupFieldController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: GridMerge/ColumnsGroupField
        public IActionResult Index()
        {
            return View();
        }


    }
}