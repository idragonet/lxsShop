﻿using FineUICore.Examples.Areas.DataModel.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FineUICore.Examples.Areas.DataModel.Controllers
{
    [Area("DataModel")]
    public class GridController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: DataModel/Grid
        public IActionResult Index()
        {
            return View(StudentHelper.GetSimpleStudentList());
        }


    }
}