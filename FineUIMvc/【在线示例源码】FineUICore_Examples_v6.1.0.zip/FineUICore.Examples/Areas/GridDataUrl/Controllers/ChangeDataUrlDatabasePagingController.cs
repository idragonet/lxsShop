﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using Newtonsoft.Json.Linq;


namespace FineUICore.Examples.Areas.GridDataUrl.Controllers
{
    [Area("GridDataUrl")]
    public class ChangeDataUrlDatabasePagingController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: GridDataUrl/ChangeDataUrlDatabasePaging
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Button2_Click(string gridSourceKey)
        {
            var grid1 = UIHelper.Grid("Grid1");

            // 重置为第一页
            grid1.PageIndex(0);

            if (gridSourceKey == "source1")
            {
                grid1.Attribute("data-source-key", "source2");
                grid1.DataUrl(Url.Content("~/GridDataUrl/PagingDatabaseData?data2=true"));
            }
            else
            {
                grid1.Attribute("data-source-key", "source1");
                grid1.DataUrl(Url.Content("~/GridDataUrl/PagingDatabaseData"));
            }

            return UIHelper.Result();
        }

    }
}