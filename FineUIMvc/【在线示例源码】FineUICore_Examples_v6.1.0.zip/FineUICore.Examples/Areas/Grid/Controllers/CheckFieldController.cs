﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Grid.Controllers
{
    [Area("Grid")]
    public class CheckFieldController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Grid/CheckField
        public IActionResult Index()
        {
            return View();
        }

       
    }
}