﻿using FineUICore.Examples.Areas.DataModel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.DataModel.Controllers
{
	[Area("DataModel")]
    public class ComplexColumnClientController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: DataModel/ComplexColumnClient
        public IActionResult Index()
        {
            return View(StudentHelper.GetSimpleStudentList<StudentExtended>());
        }


    }
}