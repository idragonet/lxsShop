﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Config.Controllers
{
    [Area("Config")]
    public class ModifyWebConfigController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Config/ModifyWebConfig
        public IActionResult Index()
        {
            return View();
        }

    }
}