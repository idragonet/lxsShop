﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Form.Controllers
{
    [Area("Form")]
    public class DatePickerRangeController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Form/DatePickerRange
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult btnSubmit_Click(string date)
        {
            UIHelper.Label("labResult").Text(String.Format("选择的日期：{0}", date));

            return UIHelper.Result();
        }

    }
}