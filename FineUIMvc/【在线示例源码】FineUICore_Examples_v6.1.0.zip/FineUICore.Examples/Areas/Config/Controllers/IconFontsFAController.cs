﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Config.Controllers
{
    [Area("Config")]
    public class IconFontsFAController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Config/IconFontsFA
        public IActionResult Index()
        {
            return View();
        }


    }
}