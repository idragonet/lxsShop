﻿using FineUICore.Examples.Areas.DataModel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace FineUICore.Examples.Areas.DataModel.Controllers
{
    [Area("DataModel")]
    public class LoginController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: DataModel/Login
        public IActionResult Index()
        {
            return View(new User());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult btnLogin_Click(IFormCollection values)
        {
            var userName = values["UserName"];
            var password = values["Password"];

            if (userName == "admin" && password == "admin888")
            {
                ShowNotify("成功登录！", MessageBoxIcon.Success);
            }
            else
            {
                ShowNotify(String.Format("用户名（{0}）或密码（{1}）错误！",
                        HttpUtility.HtmlEncode(userName),
                        HttpUtility.HtmlEncode(password)), MessageBoxIcon.Error);
            }

            return UIHelper.Result();
        }


    }
}