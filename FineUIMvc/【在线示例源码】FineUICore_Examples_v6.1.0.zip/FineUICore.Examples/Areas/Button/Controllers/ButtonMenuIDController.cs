﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNetCore.Mvc;

namespace FineUICore.Examples.Areas.Button.Controllers
{
    [Area("Button")]
    public class ButtonMenuIDController : FineUICore.Examples.Controllers.BaseController
    {
        // GET: Button/ButtonMenuID
        public IActionResult Index()
        {
            return View();
        }

    }
}